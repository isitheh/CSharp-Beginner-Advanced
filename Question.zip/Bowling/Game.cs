﻿using System;

namespace Bowling
{
    internal class Game
    {

        public void Roll(int pins)
        {
            throw new NotImplementedException();
		}

        public void Roll(int[] pins)
        {
            throw new NotImplementedException();
        }

        public int Score()
        {
            throw new NotImplementedException();
        }
    }
}
