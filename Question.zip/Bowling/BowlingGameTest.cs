﻿using Bowling;
using System;
using Xunit;

namespace Bowling
{
    public class BowlingGamesTest
    {
        private Game _game;

        public BowlingGamesTest()
        {
            _game = new Game();
        }

        private void rollMany(int rolls, int pins)
        {
            for (int i = 0; i < rolls; i++)
            {
                _game.Roll(pins);
            }
        }

        private void rollSpare()
        {
            _game.Roll(6);
            _game.Roll(4);
        }

        [Fact]
        private void Roll_GutterGame_ScoreZero()
        {
            rollMany(20, 0);
            Assert.Equal(0, _game.Score());
        }

        [Fact]
        public void Roll_TestAllOnes_ScoreAddsOnes()
        {
            rollMany(20, 1);
            Assert.Equal(20, _game.Score());
        }

        [Fact]
        public void Roll_TestOneSpare_ScoreInvolvesSpareCalculation()
        {
            rollSpare();
            _game.Roll(4);
            rollMany(17, 0);
            Assert.Equal(18, _game.Score());
        }

        [Fact]
        public void Roll_TestOneStrike_ScoreInvolvesStrikeCalculation()
        {
            _game.Roll(10);
            _game.Roll(4);
            _game.Roll(5);
            rollMany(17, 0);
            Assert.Equal(28, _game.Score());
        }

        [Fact]
        public void Roll_TestPerfectGame_PerfectBowlingScore()
        {
            rollMany(12, 10);
            Assert.Equal(300, _game.Score());
        }

        [Fact]
        public void TestRandomGameNoExtraRoll()
        {
            _game.Roll(new int[] { 1, 3, 7, 3, 10, 1, 7, 5, 2, 5, 3, 8, 2, 8, 2, 10, 9, 0 });
            Assert.Equal(131, _game.Score());
        }

        [Fact]
        public void TestRandomGameWithSpareThenStrikeAtEnd()
        {
            _game.Roll(new int[] { 1, 3, 7, 3, 10, 1, 7, 5, 2, 5, 3, 8, 2, 8, 2, 10, 9, 1, 10 });
            Assert.Equal(143, _game.Score());
        }

        [Fact]
        public void TestRandomGameWithThreeStrikesAtEnd()
        {
            _game.Roll(new int[] { 1, 3, 7, 3, 10, 1, 7, 5, 2, 5, 3, 8, 2, 8, 2, 10, 10, 10, 10 });
            Assert.Equal(163, _game.Score());
        }
    }
}
